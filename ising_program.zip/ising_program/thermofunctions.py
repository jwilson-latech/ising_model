import numpy as np
window = np.array( [[0,1,0],\
					[1,0,1],\
					[0,1,0]])

def calcEnergy(config,beta,mu):
	beta*(self.config*2\
			*convolve(config,self.window,mode='wrap')+2*mu*config)

